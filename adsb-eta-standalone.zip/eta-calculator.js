#!/usr/bin/env node
"use strict";

const fs = require("node:fs");

const ADSB_FI_API_BASE_URL = "https://opendata.adsb.fi/api";
const EARTH_RADIUS_NM = 3440.065;
const APPROACH_SEGMENT_NM = 15;
const TAXI_DEFAULT_MINUTES = 3;
const TAXI_MIN_MINUTES = 1;
const TAXI_MAX_MINUTES = 8;
const TAXI_ASSUMED_SPEED_KT = 12;
const TAXI_MIN_USEFUL_SPEED_KT = 5;
const TAXI_MAX_USEFUL_SPEED_KT = 25;
const STATUTE_MILES_PER_NAUTICAL_MILE = 1.150779448;
const ON_GROUND_DESTINATION_RADIUS_SM = 5;
const ON_GROUND_DESTINATION_RADIUS_NM = ON_GROUND_DESTINATION_RADIUS_SM / STATUTE_MILES_PER_NAUTICAL_MILE;

const ETA_STATUS_COUNTDOWN = "countdown";
const ETA_STATUS_ON_GROUND_REMOTE = "on_ground";
const ETA_STATUS_UNAVAILABLE = "unavailable";

const DEFAULT_DESTINATION = Object.freeze({
  name: "Configured Destination",
  latitude: 36.58945221767374,
  longitude: -121.85851779542429
});

const APPROACH_SPEEDS_KT = Object.freeze({
  C150: 65,
  C152: 65,
  C162: 65,
  C172: 70,
  C177: 75,
  C182: 80,
  C185: 85,
  C206: 85,
  C207: 85,
  C208: 95,
  C210: 90,
  C310: 105,
  C340: 110,
  C414: 110,
  C421: 115,
  C425: 115,
  C441: 120,
  P28A: 75,
  PA28: 75,
  PA32: 85,
  PA34: 90,
  PA46: 100,
  P46T: 105,
  SR20: 85,
  SR22: 90,
  BE33: 90,
  BE35: 90,
  BE36: 95,
  BE55: 100,
  BE58: 105,
  BE9L: 105,
  BE20: 120,
  B200: 120,
  B300: 125,
  B350: 125,
  E110: 105,
  E120: 120,
  PC12: 110,
  TBM7: 115,
  TBM8: 120,
  TBM9: 120,
  TBM: 120,
  BE40: 125,
  C500: 120,
  C501: 120,
  C510: 115,
  C525: 120,
  C25A: 120,
  C25B: 125,
  C25C: 125,
  C550: 125,
  C551: 125,
  C560: 130,
  C56X: 130,
  C650: 135,
  C680: 135,
  C68A: 135,
  C700: 135,
  C750: 140,
  LJ23: 125,
  LJ24: 125,
  LJ25: 125,
  LJ31: 125,
  LJ35: 130,
  LJ40: 130,
  LJ45: 130,
  LJ55: 135,
  LJ60: 135,
  LJ70: 135,
  LJ75: 135,
  GLF2: 135,
  GLF3: 135,
  GLF4: 140,
  GLF5: 145,
  GLF6: 145,
  GLF7: 145,
  G150: 130,
  G200: 135,
  G280: 135,
  FA10: 130,
  FA20: 130,
  FA50: 135,
  F2TH: 135,
  F2LX: 135,
  FA7X: 140,
  FA8X: 140,
  F900: 140,
  F9EX: 140,
  CL30: 135,
  CL35: 135,
  CL60: 140,
  CL6T: 140,
  BD700: 145,
  GLEX: 145,
  GL5T: 145,
  GL6T: 145,
  E50P: 115,
  E55P: 125,
  E135: 125,
  E145: 130,
  E545: 130,
  E550: 135,
  E170: 135,
  E75L: 135,
  E75S: 135,
  E190: 140,
  E195: 140,
  E290: 140,
  E295: 140,
  B731: 135,
  B732: 135,
  B733: 140,
  B734: 140,
  B735: 135,
  B736: 135,
  B737: 140,
  B738: 140,
  B739: 145,
  B37M: 140,
  B38M: 140,
  B39M: 145,
  A318: 135,
  A319: 135,
  A320: 140,
  A321: 145,
  A20N: 140,
  A21N: 145,
  CRJ1: 125,
  CRJ2: 125,
  CRJ7: 130,
  CRJ9: 135,
  CRJX: 135,
  BCS1: 135,
  BCS3: 140
});

async function main() {
  const options = parseArgs(process.argv.slice(2));

  if (options.help) {
    printHelp();
    return;
  }

  validateOptions(options);

  const serialStream = options.serial ? createSerialStream(options.serial) : null;

  do {
    const result = await getEtaFromAdsbFi(options);
    const output = formatOutput(result, options.format);

    console.log(output);

    if (serialStream) {
      serialStream.write(`${output}\n`);
    }

    if (options.watch) {
      await delay(options.intervalSeconds * 1000);
    }
  } while (options.watch);
}

async function getEtaFromAdsbFi(options) {
  const aircraft = await fetchAircraftFromAdsbFi(options);

  if (!aircraft) {
    return unavailableResult("No aircraft returned by ADSB.fi.");
  }

  return calculateEtaForAircraft(aircraft, {
    name: options.destinationName,
    latitude: options.destinationLatitude,
    longitude: options.destinationLongitude
  });
}

async function fetchAircraftFromAdsbFi(options) {
  const url = buildAdsbFiUrl(options);
  const response = await fetch(url, {
    headers: {
      accept: "application/json",
      "user-agent": "adsb-eta-standalone/1.0"
    }
  });

  if (!response.ok) {
    throw new Error(`ADSB.fi request failed: HTTP ${response.status} ${response.statusText}`);
  }

  const payload = await response.json();
  const aircraft = normalizeAdsbFiResponse(payload);

  if (aircraft.length === 0) {
    return null;
  }

  return chooseAircraft(aircraft, options);
}

function buildAdsbFiUrl(options) {
  const apiBaseUrl = options.apiBaseUrl.replace(/\/+$/, "");

  if (options.hex) {
    return `${apiBaseUrl}/v2/hex/${encodeURIComponent(options.hex)}`;
  }

  if (options.callsign) {
    return `${apiBaseUrl}/v2/callsign/${encodeURIComponent(options.callsign)}`;
  }

  if (options.registration) {
    return `${apiBaseUrl}/v2/registration/${encodeURIComponent(options.registration)}`;
  }

  throw new Error("Provide --hex, --callsign, or --registration.");
}

function normalizeAdsbFiResponse(payload) {
  const rawAircraft = Array.isArray(payload?.ac)
    ? payload.ac
    : Array.isArray(payload?.aircraft)
      ? payload.aircraft
      : [];

  return rawAircraft.map(normalizeAdsbFiAircraft).filter(Boolean);
}

function normalizeAdsbFiAircraft(rawAircraft) {
  if (!rawAircraft || typeof rawAircraft !== "object") {
    return null;
  }

  const latitude = toFiniteNumber(rawAircraft.lat ?? rawAircraft.latitude);
  const longitude = toFiniteNumber(rawAircraft.lon ?? rawAircraft.longitude);

  return {
    hex: cleanString(rawAircraft.hex),
    flight: cleanString(rawAircraft.flight),
    registration: cleanString(rawAircraft.r ?? rawAircraft.reg ?? rawAircraft.registration),
    icaoType: cleanString(rawAircraft.t ?? rawAircraft.type ?? rawAircraft.icaoType),
    latitude,
    longitude,
    groundSpeedKt: toFiniteNumber(rawAircraft.gs ?? rawAircraft.gspeed ?? rawAircraft.speed),
    altitude: rawAircraft.alt_baro ?? rawAircraft.altitude ?? rawAircraft.alt_geom ?? null,
    onGround: isAircraftOnGround(rawAircraft)
  };
}

function chooseAircraft(aircraft, options) {
  if (options.hex) {
    const requestedHex = options.hex.toLowerCase();
    return aircraft.find((candidate) => candidate.hex?.toLowerCase() === requestedHex) || aircraft[0];
  }

  if (options.callsign) {
    const requestedCallsign = normalizeCallsign(options.callsign);
    return aircraft.find((candidate) => normalizeCallsign(candidate.flight) === requestedCallsign) || aircraft[0];
  }

  if (options.registration) {
    const requestedRegistration = options.registration.toUpperCase();
    return (
      aircraft.find((candidate) => candidate.registration?.toUpperCase() === requestedRegistration) || aircraft[0]
    );
  }

  return aircraft[0];
}

function calculateEtaForAircraft(aircraft, destination) {
  if (!hasValidPosition(aircraft)) {
    return unavailableResult("Aircraft position is unavailable.");
  }

  const distanceNm = haversineDistanceNm(
    aircraft.latitude,
    aircraft.longitude,
    destination.latitude,
    destination.longitude
  );
  const approachSpeedKt = getApproachSpeedKt(aircraft.icaoType, aircraft.groundSpeedKt);
  const etaStatus = getEtaStatus(aircraft.onGround, distanceNm);
  const taxiMinutes = calculateTaxiMinutes(distanceNm, aircraft.groundSpeedKt, aircraft.onGround);
  const etaMinutes =
    etaStatus === ETA_STATUS_ON_GROUND_REMOTE
      ? null
      : calculateEtaMinutes(distanceNm, aircraft.groundSpeedKt, approachSpeedKt, aircraft.onGround, taxiMinutes);

  return {
    status: etaStatus,
    etaMinutes,
    etaMinutesRounded: etaMinutes === null ? null : Math.round(etaMinutes),
    etaText: formatEtaText(etaStatus, etaMinutes),
    etaTimeLocal24: formatEtaClockTime(etaStatus, etaMinutes),
    distanceNm,
    distanceText: formatDistance(distanceNm),
    onGround: aircraft.onGround,
    destinationName: destination.name
  };
}

function calculateEtaMinutes(distanceNm, groundSpeedKt, approachSpeedKt, onGround, taxiMinutes) {
  const normalizedDistance = toFiniteNumber(distanceNm);
  const cruiseSpeed = toFiniteNumber(groundSpeedKt);
  const approachSpeed = toFiniteNumber(approachSpeedKt);
  const normalizedTaxiMinutes = toFiniteNumber(taxiMinutes);

  if (normalizedDistance === null || normalizedDistance < 0) {
    return null;
  }

  if (onGround) {
    return normalizedTaxiMinutes;
  }

  if (approachSpeed === null || approachSpeed <= 0 || normalizedTaxiMinutes === null) {
    return null;
  }

  const approachDistanceNm = Math.min(normalizedDistance, APPROACH_SEGMENT_NM);
  const cruiseDistanceNm = Math.max(0, normalizedDistance - APPROACH_SEGMENT_NM);

  if (cruiseDistanceNm > 0 && (cruiseSpeed === null || cruiseSpeed <= 0)) {
    return null;
  }

  const cruiseHours = cruiseDistanceNm > 0 ? cruiseDistanceNm / cruiseSpeed : 0;
  const approachHours = approachDistanceNm / approachSpeed;

  return (cruiseHours + approachHours) * 60 + normalizedTaxiMinutes;
}

function calculateTaxiMinutes(distanceNm, groundSpeedKt, onGround) {
  const distance = toFiniteNumber(distanceNm);
  const groundSpeed = toFiniteNumber(groundSpeedKt);

  if (!onGround) {
    return TAXI_DEFAULT_MINUTES;
  }

  if (distance === null || distance < 0) {
    return TAXI_DEFAULT_MINUTES;
  }

  if (distance <= 0.05) {
    return 0;
  }

  const taxiSpeedKt =
    groundSpeed === null || groundSpeed < TAXI_MIN_USEFUL_SPEED_KT
      ? TAXI_ASSUMED_SPEED_KT
      : Math.min(TAXI_MAX_USEFUL_SPEED_KT, Math.max(TAXI_MIN_USEFUL_SPEED_KT, groundSpeed));
  const taxiMinutes = (distance / taxiSpeedKt) * 60;

  return Math.min(TAXI_MAX_MINUTES, Math.max(TAXI_MIN_MINUTES, taxiMinutes));
}

function getEtaStatus(onGround, distanceNm) {
  const distance = toFiniteNumber(distanceNm);

  if (distance === null) {
    return ETA_STATUS_UNAVAILABLE;
  }

  if (onGround && distance > ON_GROUND_DESTINATION_RADIUS_NM) {
    return ETA_STATUS_ON_GROUND_REMOTE;
  }

  return ETA_STATUS_COUNTDOWN;
}

function getApproachSpeedKt(icaoType, groundSpeedKt) {
  const normalizedType = normalizeAircraftType(icaoType);

  if (normalizedType && APPROACH_SPEEDS_KT[normalizedType]) {
    return APPROACH_SPEEDS_KT[normalizedType];
  }

  const categorySpeed = getCategoryApproachSpeedKt(normalizedType);
  if (categorySpeed !== null) {
    return categorySpeed;
  }

  return getSpeedBasedFallbackKt(groundSpeedKt);
}

function getCategoryApproachSpeedKt(icaoType) {
  if (!icaoType) {
    return null;
  }

  if (/^(A3|A20|A21|B7|B37|B38|B39|BCS|CRJ|E17|E19|E29|E75)/.test(icaoType)) {
    return 140;
  }

  if (/^(C5|C6|C7|C25|C68|CL|GL|G1|G2|G3|FA|F2|F9|LJ|E5)/.test(icaoType)) {
    return 135;
  }

  if (/^(BE2|B2|B3|PC12|TBM|C208|C4|P46|E12)/.test(icaoType)) {
    return 115;
  }

  if (/^(C1|C2|C3|PA|P28|SR|BE3|BE5)/.test(icaoType)) {
    return 90;
  }

  return null;
}

function getSpeedBasedFallbackKt(groundSpeedKt) {
  const speed = toFiniteNumber(groundSpeedKt);

  if (speed === null) {
    return 120;
  }

  if (speed >= 250) {
    return 135;
  }

  if (speed >= 150) {
    return 120;
  }

  if (speed >= 95) {
    return 105;
  }

  return 80;
}

function isAircraftOnGround(aircraft) {
  if (!aircraft || typeof aircraft !== "object") {
    return false;
  }

  if (aircraft.onGround === true || aircraft.on_ground === true) {
    return true;
  }

  return isGroundAltitude(aircraft.alt_baro) || isGroundAltitude(aircraft.altitude) || isGroundAltitude(aircraft.alt_geom);
}

function isGroundAltitude(value) {
  return typeof value === "string" && value.trim().toLowerCase() === "ground";
}

function hasValidPosition(aircraft) {
  return toFiniteNumber(aircraft?.latitude) !== null && toFiniteNumber(aircraft?.longitude) !== null;
}

function haversineDistanceNm(fromLatitude, fromLongitude, toLatitude, toLongitude) {
  const fromLatRad = degreesToRadians(fromLatitude);
  const toLatRad = degreesToRadians(toLatitude);
  const deltaLatRad = degreesToRadians(toLatitude - fromLatitude);
  const deltaLonRad = degreesToRadians(toLongitude - fromLongitude);

  const halfChord =
    Math.sin(deltaLatRad / 2) ** 2 +
    Math.cos(fromLatRad) * Math.cos(toLatRad) * Math.sin(deltaLonRad / 2) ** 2;

  const centralAngle = 2 * Math.atan2(Math.sqrt(halfChord), Math.sqrt(1 - halfChord));
  return EARTH_RADIUS_NM * centralAngle;
}

function formatOutput(result, format) {
  if (format === "arduino") {
    return formatArduinoLine(result);
  }

  if (format === "text") {
    return formatTextLine(result);
  }

  return JSON.stringify(result);
}

function formatArduinoLine(result) {
  return [
    `STATUS=${arduinoStatus(result.status)}`,
    `ETA_MIN=${result.etaMinutesRounded ?? -1}`,
    `ETA_TIME=${result.etaTimeLocal24 ? result.etaTimeLocal24.replace(":", "") : "NA"}`,
    `DIST_NM=${Number.isFinite(result.distanceNm) ? result.distanceNm.toFixed(1) : "NA"}`,
    `ON_GROUND=${result.onGround ? 1 : 0}`
  ].join(";");
}

function formatTextLine(result) {
  if (result.status === ETA_STATUS_ON_GROUND_REMOTE) {
    return `ETA On ground / ${result.distanceText}`;
  }

  if (result.status === ETA_STATUS_UNAVAILABLE) {
    return `ETA N/A / ${result.reason}`;
  }

  return `ETA ${result.etaText} / ${result.etaTimeLocal24} / ${result.distanceText}`;
}

function arduinoStatus(status) {
  if (status === ETA_STATUS_COUNTDOWN) {
    return "COUNTDOWN";
  }

  if (status === ETA_STATUS_ON_GROUND_REMOTE) {
    return "ON_GROUND";
  }

  return "NA";
}

function formatEtaText(status, etaMinutes) {
  const normalizedEtaMinutes = toFiniteNumber(etaMinutes);

  if (status === ETA_STATUS_ON_GROUND_REMOTE) {
    return "On ground";
  }

  if (normalizedEtaMinutes === null || normalizedEtaMinutes < 0) {
    return "N/A";
  }

  if (normalizedEtaMinutes < 1) {
    return "<1 min";
  }

  const roundedMinutes = Math.round(normalizedEtaMinutes);

  if (roundedMinutes < 60) {
    return `~${roundedMinutes} min`;
  }

  const hours = Math.floor(roundedMinutes / 60);
  const minutesRemainder = roundedMinutes % 60;

  if (minutesRemainder === 0) {
    return `~${hours} hr`;
  }

  return `~${hours} hr ${minutesRemainder} min`;
}

function formatEtaClockTime(status, etaMinutes) {
  const normalizedEtaMinutes = toFiniteNumber(etaMinutes);

  if (status !== ETA_STATUS_COUNTDOWN || normalizedEtaMinutes === null || normalizedEtaMinutes < 0) {
    return null;
  }

  const etaDate = new Date(Date.now() + normalizedEtaMinutes * 60 * 1000);
  return `${padTwoDigits(etaDate.getHours())}:${padTwoDigits(etaDate.getMinutes())}`;
}

function formatDistance(distanceNm) {
  const distance = toFiniteNumber(distanceNm);
  return distance === null ? "N/A" : `${distance.toFixed(1)} NM`;
}

function unavailableResult(reason) {
  return {
    status: ETA_STATUS_UNAVAILABLE,
    etaMinutes: null,
    etaMinutesRounded: null,
    etaText: "N/A",
    etaTimeLocal24: null,
    distanceNm: null,
    distanceText: "N/A",
    onGround: false,
    destinationName: null,
    reason
  };
}

function parseArgs(argv) {
  const options = {
    apiBaseUrl: ADSB_FI_API_BASE_URL,
    destinationName: DEFAULT_DESTINATION.name,
    destinationLatitude: DEFAULT_DESTINATION.latitude,
    destinationLongitude: DEFAULT_DESTINATION.longitude,
    format: "json",
    intervalSeconds: 5,
    serial: null,
    watch: false,
    help: false,
    hex: null,
    callsign: null,
    registration: null
  };

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];

    switch (arg) {
      case "--help":
      case "-h":
        options.help = true;
        break;
      case "--hex":
      case "--icao":
        options.hex = nextArgValue(argv, (index += 1), arg).toLowerCase();
        break;
      case "--callsign":
        options.callsign = nextArgValue(argv, (index += 1), arg).toUpperCase();
        break;
      case "--registration":
      case "--reg":
        options.registration = nextArgValue(argv, (index += 1), arg).toUpperCase();
        break;
      case "--dest-name":
        options.destinationName = nextArgValue(argv, (index += 1), arg);
        break;
      case "--dest-lat":
        options.destinationLatitude = toFiniteNumber(nextArgValue(argv, (index += 1), arg));
        break;
      case "--dest-lon":
        options.destinationLongitude = toFiniteNumber(nextArgValue(argv, (index += 1), arg));
        break;
      case "--format":
        options.format = nextArgValue(argv, (index += 1), arg).toLowerCase();
        break;
      case "--watch":
        options.watch = true;
        break;
      case "--interval":
        options.intervalSeconds = Math.max(1, toFiniteNumber(nextArgValue(argv, (index += 1), arg)) ?? 5);
        break;
      case "--serial":
        options.serial = nextArgValue(argv, (index += 1), arg);
        break;
      case "--api-base":
        options.apiBaseUrl = nextArgValue(argv, (index += 1), arg);
        break;
      default:
        throw new Error(`Unknown option: ${arg}`);
    }
  }

  return options;
}

function validateOptions(options) {
  const identifierCount = [options.hex, options.callsign, options.registration].filter(Boolean).length;

  if (identifierCount !== 1) {
    throw new Error("Provide exactly one aircraft identifier: --hex, --callsign, or --registration.");
  }

  if (options.destinationLatitude === null || options.destinationLatitude < -90 || options.destinationLatitude > 90) {
    throw new Error("Provide a valid --dest-lat from -90 to 90.");
  }

  if (
    options.destinationLongitude === null ||
    options.destinationLongitude < -180 ||
    options.destinationLongitude > 180
  ) {
    throw new Error("Provide a valid --dest-lon from -180 to 180.");
  }

  if (!["json", "text", "arduino"].includes(options.format)) {
    throw new Error("--format must be json, text, or arduino.");
  }
}

function nextArgValue(argv, index, flag) {
  const value = argv[index];

  if (!value || value.startsWith("--")) {
    throw new Error(`${flag} requires a value.`);
  }

  return value;
}

function createSerialStream(serialPath) {
  const normalizedPath = normalizeSerialPath(serialPath);
  return fs.createWriteStream(normalizedPath, { flags: "a" });
}

function normalizeSerialPath(serialPath) {
  if (/^COM\d+$/i.test(serialPath)) {
    return `\\\\.\\${serialPath.toUpperCase()}`;
  }

  return serialPath;
}

function normalizeAircraftType(icaoType) {
  if (typeof icaoType !== "string") {
    return null;
  }

  const cleaned = icaoType.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  return cleaned === "" ? null : cleaned;
}

function normalizeCallsign(callsign) {
  return typeof callsign === "string" ? callsign.trim().replace(/\s+/g, "").toUpperCase() : "";
}

function cleanString(value) {
  if (typeof value !== "string") {
    return null;
  }

  const cleaned = value.trim();
  return cleaned === "" ? null : cleaned;
}

function toFiniteNumber(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }

  if (typeof value === "string" && value.trim() !== "") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }

  return null;
}

function degreesToRadians(degrees) {
  return (degrees * Math.PI) / 180;
}

function padTwoDigits(value) {
  return String(value).padStart(2, "0");
}

function delay(milliseconds) {
  return new Promise((resolve) => {
    setTimeout(resolve, milliseconds);
  });
}

function printHelp() {
  console.log(`ADS-B ETA standalone calculator

Usage:
  node eta-calculator.js --hex 461e1a --dest-lat 36.58945 --dest-lon -121.85852
  node eta-calculator.js --callsign UAL2854 --dest-lat 36.58945 --dest-lon -121.85852 --format text
  node eta-calculator.js --registration N38268 --dest-lat 36.58945 --dest-lon -121.85852 --format arduino
  node eta-calculator.js --hex 461e1a --dest-lat 36.58945 --dest-lon -121.85852 --watch --interval 5 --format arduino --serial COM3

Aircraft lookup:
  --hex <mode-s-hex>          ADSB.fi /v2/hex lookup
  --icao <mode-s-hex>         Alias for --hex
  --callsign <callsign>       ADSB.fi /v2/callsign lookup
  --registration <reg>        ADSB.fi /v2/registration lookup

Destination:
  --dest-lat <latitude>
  --dest-lon <longitude>
  --dest-name <name>          Optional, included in JSON output only

Output:
  --format json               Default JSON result
  --format text               Human-readable one-line result
  --format arduino            Compact key/value line: STATUS=...;ETA_MIN=...;ETA_TIME=...;DIST_NM=...

Arduino / serial:
  --serial <port>             Writes the selected output format to COM3, /dev/ttyUSB0, etc.
  --watch                     Repeat until stopped
  --interval <seconds>        Poll interval, minimum 1 second because ADSB.fi public endpoints are rate-limited

Advanced:
  --api-base <url>            Default: ${ADSB_FI_API_BASE_URL}
`);
}

module.exports = {
  calculateEtaForAircraft,
  normalizeAdsbFiAircraft,
  normalizeAdsbFiResponse,
  fetchAircraftFromAdsbFi,
  formatArduinoLine,
  formatEtaText,
  haversineDistanceNm
};

if (require.main === module) {
  main().catch((error) => {
    console.error(`ERROR: ${error.message}`);
    process.exitCode = 1;
  });
}
