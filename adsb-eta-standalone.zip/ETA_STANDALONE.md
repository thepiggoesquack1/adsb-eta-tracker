# Standalone ADS-B ETA Calculator

`eta-calculator.js` is a Node.js program that contains only the ETA calculation and ADSB.fi aircraft lookup logic. It does not use Chrome extension APIs, DOM APIs, the ADS-B Exchange page, or the floating panel.

It is intended for running on a computer that can then forward the ETA result to another device, such as an Arduino.

## Requirements

- Node.js 18 or newer
- Internet access to `https://opendata.adsb.fi/api/`

## ADSB.fi Lookup

The script uses ADSB.fi open-data endpoints:

```text
https://opendata.adsb.fi/api/v2/hex/[hex]
https://opendata.adsb.fi/api/v2/callsign/[callsign]
https://opendata.adsb.fi/api/v2/registration/[registration]
```

The ADSB.fi public API is rate-limited, so keep polling intervals at 1 second or slower. The default watch interval is 5 seconds.

## Basic Usage

```powershell
node eta-calculator.js --hex 461e1a --dest-lat 36.58945221767374 --dest-lon -121.85851779542429
```

Human-readable output:

```powershell
node eta-calculator.js --callsign UAL2854 --dest-lat 36.58945221767374 --dest-lon -121.85851779542429 --format text
```

Arduino-friendly output:

```powershell
node eta-calculator.js --registration N38268 --dest-lat 36.58945221767374 --dest-lon -121.85851779542429 --format arduino
```

Example Arduino line:

```text
STATUS=COUNTDOWN;ETA_MIN=13;ETA_TIME=1418;DIST_NM=24.9;ON_GROUND=0
```

If the aircraft is on the ground more than 5 statute miles from the selected destination:

```text
STATUS=ON_GROUND;ETA_MIN=-1;ETA_TIME=NA;DIST_NM=66.0;ON_GROUND=1
```

## Continuous Polling

```powershell
node eta-calculator.js --hex 461e1a --dest-lat 36.58945221767374 --dest-lon -121.85851779542429 --watch --interval 5 --format arduino
```

## Serial Output

The script can also write each output line to a serial device:

```powershell
node eta-calculator.js --hex 461e1a --dest-lat 36.58945221767374 --dest-lon -121.85851779542429 --watch --interval 5 --format arduino --serial COM3
```

The script does not configure serial baud rate itself. Configure the port separately for your Arduino sketch, for example `9600 8N1`.

## Calculation Behavior

- Airborne ETA is cruise segment + approach segment + default taxi time.
- Approach speed is selected from the aircraft ICAO type when known.
- Unknown aircraft types use category and speed-based fallbacks.
- On-ground aircraft within 5 statute miles of the destination use taxi-only ETA.
- On-ground aircraft farther than 5 statute miles show `STATUS=ON_GROUND` instead of a misleading ETA.
- `ETA_TIME` uses the computer's local timezone in 24-hour `HHMM` format for Arduino output.
